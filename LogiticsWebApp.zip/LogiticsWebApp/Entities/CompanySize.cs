﻿using LogiticsWebApp.Data;
using System;
using System.Collections.Generic;

namespace LogiticsWebApp.Entities
{
    public partial class CompanySize
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
