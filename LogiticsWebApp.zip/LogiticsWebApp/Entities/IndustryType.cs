﻿using LogiticsWebApp.Data;
using System;
using System.Collections.Generic;

namespace LogiticsWebApp.Entities
{
    public partial class IndustryType
    {
        public int Id { get; set; }
        public string Name { get; set; }

    }
}
