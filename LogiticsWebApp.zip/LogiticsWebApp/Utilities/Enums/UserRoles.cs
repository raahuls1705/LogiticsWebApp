﻿namespace LogiticsWebApp.Utilities.Enums
{
    public enum UserRoles
    {
        Admin = 1,
        Vendor = 2,
        Driver = 3,
        Customer = 4,
        CompanyOwner = 5
    }
}
