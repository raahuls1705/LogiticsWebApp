﻿namespace LogiticsWebApp.Utilities.Enums
{
    public enum NotificationStatus
    {
        Success,
        Errors,
        Warnings
    }
}
